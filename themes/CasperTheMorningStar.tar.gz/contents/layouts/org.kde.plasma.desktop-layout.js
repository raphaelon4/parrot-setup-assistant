var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1920x1080": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "com.darkeye.animatedImage"
                },
                "/ConfigDialog": {
                    "DialogHeight": "759",
                    "DialogWidth": "965"
                },
                "/General": {
                    "ToolBoxButtonState": "top",
                    "ToolBoxButtonY": "38"
                },
                "/Wallpaper/com.darkeye.animatedImage/General": {
                    "FillMode": "2",
                    "Image": "file:///home/ranjeet/Pictures/wallpapers/casper (1).gif"
                }
            },
            "wallpaperPlugin": "com.darkeye.animatedImage"
        },
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1920x1080": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "1",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
