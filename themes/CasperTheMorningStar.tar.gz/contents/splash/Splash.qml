import QtQuick 2.5
import QtQuick.Window 2.2

// AnimatedImage is a QML element that displays an animated image
AnimatedImage {
    id: root
    source: "images/casper_tms.gif" // The path to the image file to display
    property int stage // Custom integer property

    // This function is called when the value of the 'stage' property changes
    onStageChanged: {
        if (stage == 1) {
            introAnimation.running = true; // Start the intro animation
        } else if (stage == 5) {
            introAnimation.target = busyIndicator; // Set the target object for the animation
            introAnimation.from = 1; // Set the starting opacity value
            introAnimation.to = 0; // Set the ending opacity value
            introAnimation.running = true; // Start the animation
        }
    }

    // Item is a basic visual element in QML that can contain other elements
    Item {
        id: content
        anchors.fill: parent // Fill the parent element
        opacity: 0 // Set the initial opacity to 0

        // TextMetrics is a QML object that provides a way to measure text
        TextMetrics {
            id: units
            text: "M"
            property int gridUnit: boundingRect.height // The height of the bounding rectangle for the text
            property int largeSpacing: units.gridUnit // The size of a large spacing unit
            property int smallSpacing: Math.max(2, gridUnit/4) // The size of a small spacing unit
        }

        // AnimatedImage to display a spinning busy indicator
        AnimatedImage {
            id: busyIndicator
            // Position the busy indicator in the middle of the remaining space
            y: parent.height - 150
            width: 75
            height: 75
            anchors.horizontalCenter: parent.horizontalCenter
            source: "images/main.gif"
        }

        // Row is a layout element that arranges child elements in a horizontal row
        Row {
            opacity: 0.5 // Set the initial opacity to 0.5
            spacing: units.smallSpacing*2 // Set the spacing between child elements
            anchors {
                bottom: parent.bottom
                // right: parent.right
                margins: units.gridUnit // Set the margins around the row
            }
            anchors.horizontalCenter: parent.horizontalCenter

            // Text element to display a welcome message
            Text {
                color: "#eff0f1"
                renderType: Screen.devicePixelRatio % 1 !== 0 ? Text.QtRendering : Text.NativeRendering
                anchors.verticalCenter: parent.verticalCenter
                text: "Welcome to Plasma"
            }

            // Image element to display the KDE logo
            Image {
                source: "images/kde.svgz"
                sourceSize.height: units.gridUnit * 2 // Set the height of the image
                sourceSize.width: units.gridUnit * 2 // Set the width of the image
            }
        }
    }

    // OpacityAnimator is a QML object that animates the opacity of a target object
    OpacityAnimator {
        id: introAnimation
        running: false // Set the animation to not be running by default
        target: content // Set the target object for the animation
        from: 0 // Set the starting opacity value
        to: 1 // Set the ending opacity value
        duration: 1000 // Set the duration of the animation in milliseconds
        easing.type: Easing.InOutQuad // Set the easing function for the animation
    }
}
